<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckAdminStatus
{
    public function handle(Request $request, Closure $next): Response
    {
        // Check if user is logged in
        if (Auth::check()) {
            $user = Auth::user();

            // Future-Proof Role Check (Allow admin, superadmin, subadmin)
            $allowedRoles = ['admin', 'superadmin', 'subadmin'];
            
            if (!in_array($user->user_role, $allowedRoles)) {
                return $this->terminateSession($request, 'Unauthorized access.');
            }

            // Check Account Status from UserInfo relationship
            // Assuming UserInfo is eagerly loaded or accessible
            if ($user->userInfo) {
                $status = strtolower($user->userInfo->account_status);
                
                if (in_array($status, ['banned', 'inactive', 'suspended'])) {
                    return $this->terminateSession($request, 'Your account has been ' . $status . '. Please contact administration.');
                }
            }

            // Check if account is Soft Deleted
            if (method_exists($user, 'trashed') && $user->trashed()) {
                 return $this->terminateSession($request, 'Your account no longer exists.');
            }

            // Check if account is Soft Deleted
            // if ($user->trashed && $user->trashed()) {
            //      return $this->terminateSession($request, 'Your account no longer exists.');
            // }

            
        }

        return $next($request);
    }

    /**
     * Helper function to logout and redirect securely
     */
    private function terminateSession(Request $request, string $message)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        // AJAX request hai toh JSON bhejo, warna redirect karo
        if ($request->expectsJson()) {
            return response()->json(['message' => $message], 403);
        }

        return redirect()->route('admin.login.index')->with('error', $message);
    }
}