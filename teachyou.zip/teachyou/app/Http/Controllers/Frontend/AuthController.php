<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserInfo;
use App\Models\LoginHistory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Jenssegers\Agent\Agent;
use App\Support\SmartLog;

class AuthController extends Controller
{
    // 1. IP Address fetch karne ka function (Local + Live handled)
    private function getRealIp(Request $request) {
        if ($request->ip() == '127.0.0.1' || $request->ip() == '::1') {
            try {
                $response = Http::timeout(3)->get('https://api.ipify.org');
                if ($response->successful()) {
                    return $response->body();
                }
            } catch (\Exception $e) {
                return $request->ip();
            }
        }
        return $request->ip();
    }

    public function getRegister()
    {
        return view('frontend.auth.register');
    }

    public function postRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'     => 'required|string|max:255',
            'username' => [
                'required', 'string', 'max:255',
                function ($attribute, $value, $fail) {
                    if (User::where('username_hash', blind_hash($value))->exists()) {
                        $fail('The username has already been taken.');
                    }
                }
            ],
            'email'    => [
                'required', 'email',
                function ($attribute, $value, $fail) {
                    if (User::where('email_hash', blind_hash($value))->exists()) {
                        $fail('The email has already been taken.');
                    }
                }
            ],
            'password' => ['required', 'confirmed', Password::min(8)->mixedCase()->numbers()->symbols()],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        try {
            DB::beginTransaction();

            // 1. Create Core User
            $user = new User();
            $user->name             = $request->name;
            $user->email            = $request->email;
            $user->username         = $request->username;
            $user->password         = Hash::make($request->password);
            $user->user_role        = 'user';
            $user->save(); 

            // 2. Create User Info
            // UserInfo::create([
            //     'user_id' => $user->id,
            //     'account_status' => 'active',
            // ]);

            DB::commit();

            // 3. Auto Login & Session Regen
            Auth::login($user);
            $request->session()->regenerate();

            // 4. Capture Exact Device Data via Agent
            $agent = new Agent();
            
            $browserName = $agent->browser();
            $browserVersion = $agent->version($browserName);
            $exactBrowser = $browserName ? ($browserName . ' ' . $browserVersion) : 'Unknown Browser';

            $osName = $agent->platform();
            $osVersion = $agent->version($osName);
            $exactOS = $osName ? ($osName . ' ' . $osVersion) : 'Unknown OS';
            
            $currentIp = $this->getRealIp($request);

            // 5. Update Tracking Info to Core User
            $user->ip_address       = $currentIp;
            $user->browser          = $exactBrowser;
            $user->operating_system = $exactOS;  
            $user->last_login       = now();
            $user->session          = $request->session()->getId(); // Captured new session!
            $user->save();

            // 6. Record First Login History
            LoginHistory::create([
                'user_id'          => $user->id,
                'ip_address'       => $currentIp,
                'browser'          => $exactBrowser,
                'operating_system' => $exactOS,
            ]);

            return response()->json([
                'message'  => 'Registration successful! Redirecting...',
                'redirect' => route('home')
            ]);

        } catch (\Throwable $th) {
            DB::rollBack();
            SmartLog::throttledError('Frontend Registration Error: ' . $th->getMessage(), [], 60);
            return response()->json(['message' => 'Failed to register. Please try again.'], 500);
        }
    }

    public function getLogin()
    {
        return view('frontend.auth.login');
    }

    public function postLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'login_id' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        $loginId = $request->login_id;
        $isEmail = filter_var($loginId, FILTER_VALIDATE_EMAIL);

        if ($isEmail) {
            $user = User::where('email_hash', blind_hash($loginId))->where('user_role', 'user')->first();
        } else {
            $user = User::where('username_hash', blind_hash($loginId))->where('user_role', 'user')->first();
        }

        if (! $user || ! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => trans('auth.failed')], 401);
        }

        // 1. Authenticate & Secure Session
        Auth::login($user, $request->boolean('remember'));
        $request->session()->regenerate();

        // 2. Extract Device Info
        $agent = new Agent();
        
        $browserName = $agent->browser();
        $browserVersion = $agent->version($browserName);
        $exactBrowser = $browserName ? ($browserName . ' ' . $browserVersion) : 'Unknown Browser';

        $osName = $agent->platform();
        $osVersion = $agent->version($osName);
        $exactOS = $osName ? ($osName . ' ' . $osVersion) : 'Unknown OS';
        
        $currentIp = $this->getRealIp($request);

        // 3. Update Current State
        $user->ip_address       = $currentIp;
        $user->browser          = $exactBrowser;
        $user->operating_system = $exactOS;  
        $user->last_login       = now();
        $user->session          = $request->session()->getId();
        $user->save();

        // 4. Create History Entry (FIXED: Using accurate $exactBrowser/$exactOS now)
        LoginHistory::create([
            'user_id'          => $user->id,
            'ip_address'       => $currentIp,
            'browser'          => $exactBrowser,
            'operating_system' => $exactOS,
        ]);

        return response()->json([
            'message'  => 'Authentication successful. Redirecting...',
            'redirect' => route('home')
        ]);
    }

    public function postLogout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}