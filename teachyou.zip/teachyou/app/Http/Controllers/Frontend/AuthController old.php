<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserInfo;
use App\Models\LoginHistory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\Support\SmartLog;

class AuthController extends Controller
{
    // Helper function to extract OS from User Agent
    private function getOS($userAgent) {
        $osPlatform = "Unknown OS Platform";
        $osArray = [
            '/windows nt 10/i'      =>  'Windows 10',
            '/windows nt 6.3/i'     =>  'Windows 8.1',
            '/windows nt 6.2/i'     =>  'Windows 8',
            '/windows nt 6.1/i'     =>  'Windows 7',
            '/macintosh|mac os x/i' =>  'Mac OS X',
            '/mac_powerpc/i'        =>  'Mac OS 9',
            '/linux/i'              =>  'Linux',
            '/ubuntu/i'             =>  'Ubuntu',
            '/iphone/i'             =>  'iPhone',
            '/ipod/i'               =>  'iPod',
            '/ipad/i'               =>  'iPad',
            '/android/i'            =>  'Android',
        ];
        foreach ($osArray as $regex => $value) {
            if (preg_match($regex, $userAgent)) {
                $osPlatform = $value;
            }
        }
        return $osPlatform;
    }

    // Helper function to extract Browser from User Agent
    private function getBrowser($userAgent) {
        $browser = "Unknown Browser";
        $browserArray = [
            '/msie/i'      => 'Internet Explorer',
            '/firefox/i'   => 'Firefox',
            '/safari/i'    => 'Safari',
            '/chrome/i'    => 'Chrome',
            '/edge/i'      => 'Edge',
            '/opera/i'     => 'Opera',
            '/netscape/i'  => 'Netscape',
            '/maxthon/i'   => 'Maxthon',
            '/konqueror/i' => 'Konqueror',
            '/mobile/i'    => 'Handheld Browser'
        ];
        foreach ($browserArray as $regex => $value) {
            if (preg_match($regex, $userAgent)) {
                $browser = $value;
            }
        }
        return $browser;
    }
    
    private function getRealIp(Request $request) {
        // Agar IP local (127.0.0.1) hai, tabhi external service ko call karenge
        if ($request->ip() == '127.0.0.1' || $request->ip() == '::1') {
            try {
                // 3 second ka timeout diya hai taaki app hang na ho
                $response = Http::timeout(3)->get('https://api.ipify.org');
                if ($response->successful()) {
                    return $response->body();
                }
            } catch (\Exception $e) {
                // Agar internet nahi hai, toh fallback local IP
                return $request->ip();
            }
        }
        
        // Live server par default Laravel IP hi best kaam karega
        return $request->ip();
    }

    public function getRegister()
    {
        return view('frontend.auth.register');
    }

    public function postRegister(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'     => 'required|string|max:255',
            'username' => [
                'required', 'string', 'max:255',
                function ($attribute, $value, $fail) {
                    if (User::where('username_hash', blind_hash($value))->exists()) {
                        $fail('The username has already been taken.');
                    }
                }
            ],
            'email'    => [
                'required', 'email',
                function ($attribute, $value, $fail) {
                    if (User::where('email_hash', blind_hash($value))->exists()) {
                        $fail('The email has already been taken.');
                    }
                }
            ],
            'password' => ['required', 'confirmed', Password::min(8)->mixedCase()->numbers()->symbols()],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        try {
            DB::beginTransaction();

            $user = new User();
            $user->name             = $request->name;
            $user->email            = $request->email;
            $user->username         = $request->username;
            $user->password         = Hash::make($request->password);
            $user->user_role        = 'user';
            $user->save(); // Pehle core data save karein

            UserInfo::create([
                'user_id' => $user->id,
                'account_status' => 'active',
            ]);

            DB::commit();

            // Auto-login after registration
            Auth::login($user);
            $request->session()->regenerate();

            // Tracking and Encrypted Data Update
            $userAgent = $request->userAgent();
            $user->ip_address       = $this->getRealIp($request);
            $user->browser          = $this->getBrowser($userAgent);
            $user->operating_system = $this->getOS($userAgent);
            $user->last_login       = now();
            $user->session          = $request->session()->getId();
            $user->save();

            return response()->json([
                'message' => 'Registration successful! Redirecting...',
                'redirect' => route('home')
            ]);

        } catch (\Throwable $th) {
            DB::rollBack();
            SmartLog::throttledError('Frontend Registration Error: ' . $th->getMessage(), [], 60);
            return response()->json(['message' => 'Failed to register. Please try again.'], 500);
        }
    }

    public function getLogin()
    {
        return view('frontend.auth.login');
    }

    public function postLogin(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'login_id' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        $loginId = $request->login_id;
        $isEmail = filter_var($loginId, FILTER_VALIDATE_EMAIL);

        if ($isEmail) {
            $user = User::where('email_hash', blind_hash($loginId))->where('user_role', 'user')->first();
        } else {
            $user = User::where('username_hash', blind_hash($loginId))->where('user_role', 'user')->first();
        }

        if (! $user || ! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => trans('auth.failed')], 401);
        }

        // 1. Pehle user ko login karwayein
        Auth::login($user, $request->boolean('remember'));
        
        // 2. Session regenerate karein (SECURITY: Session Fixation attack rokne ke liye)
        $request->session()->regenerate();

        // 3. Ab fresh aur secure session ID ke sath baaki details update karein
        // $userAgent = $request->userAgent();
        // $user->ip_address       = $this->getRealIp($request);
        // $user->browser          = $this->getBrowser($userAgent);
        // $user->operating_system = $this->getOS($userAgent);
        // $user->last_login       = now();
        // $user->session          = $request->session()->getId();
        // $user->save();

        // Purana code jahan user update ho raha tha
        $userAgent                  = $request->userAgent();
        $user->ip_address           = $this->getRealIp($request);
        $user->browser              = $this->getBrowser($userAgent);
        $user->operating_system     = $this->getOS($userAgent);
        $user->last_login           = now();
        $user->session              = $request->session()->getId();
        $user->save();

        // NAYA CODE: History me nayi row add karne ke liye
        LoginHistory::create([
            'user_id' => $user->id,
            'ip_address' => $this->getRealIp($request),
            'browser' => $this->getBrowser($userAgent),
            'operating_system' => $this->getOS($userAgent),
        ]);

        return response()->json([
            'message'  => 'Authentication successful. Redirecting...',
            'redirect' => route('home')
        ]);
    }

    public function postLogout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}