<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserInfo;
use App\Models\User;
use App\Models\LoginHistory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\Rule;
use Carbon\carbon;
use App\Support\SmartLog;

class UserController extends Controller
{
    // Users List Page Show Karega (With AJAX Filtering)
    public function getList(Request $request)
    {
        $query = User::with('userInfo')
        ->where('user_role', '!=', 'admin')
        ->orderBy('created_at', 'desc');
        // 'search_name' filter
        if ($request->filled('search_name')) {
            $query->where('name', 'like', '%' . $request->search_name . '%');
        }
        // 'search_username' filter
        if ($request->filled('search_username')) {
            $query->where('username', 'like', '%' . $request->search_username . '%');
        }
        // if ($request->filled('search_username')) {
        //     // EXACT match search using hash
        //     $query->where('username_hash', blind_hash($request->search_username));
        // }
        
        $users = $query->paginate(15);

        return view('admin.users.list', compact('users'));
    }

    // Create Page (Form) Get Karega
    public function getCreate(Request $request)
    {
        return view('admin.users.create');
    }

    // Naya User Database me Save Karega (AJAX via Modal)
    public function postCreate(Request $request)
    {
        // Validation Logic
        $validator = Validator::make($request->all(), [
            'name'     => 'required|string|max:255',
            'username' => [ 'required', 'string', 'max:255', Rule::unique('users')->whereNull('deleted_at') ],
            'email'    => [
                'required', 'email',
                // CUSTOM UNIQUE CHECK AGAINST HASH
                function ($attribute, $value, $fail) {
                    $exists = User::where('email_hash', blind_hash($value))
                                ->whereNull('deleted_at')
                                ->exists();
                    if ($exists) {
                        $fail('The email has already been taken.');
                    }
                }
            ],
            'password' => [ 'required', 'confirmed', Password::min(8)->mixedCase()->numbers()->symbols(), 'regex:/^[A-Z]\S*$/' ],
        ]);

        // Validation fail hone par JSON error response 
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        try {
            DB::beginTransaction();

            // Check karte hain ki kya ye email ya username kisi deleted user ka hai
            $user = User::withTrashed()
                ->where(function($query) use ($request) {
                    $query->where('email', $request->email) ->orWhere('username', $request->username);
                }) ->first();

            // Agar user mila aur wo deleted (trashed) hai, to restore karenge
            if ($user && $user->trashed()) {
                $user->restore(); // deleted_at ko wapas null kar dega
            } else {
                // Agar nahi mila to normally naya object banayenge
                $user = new User();
            }

            // Create Core User
            // $user = new User();
            $user->name      = $request->name;
            $user->email     = $request->email;
            $user->username  = $request->username;
            $user->password  = Hash::make($request->password);
            $user->user_role = 'user';
            $user->save();

            DB::commit();

            // Success message
            session()->flash('success', 'User created successfully.');
            return response()->json(['message' => 'User created successfully.', 'status' => 'success']);

        } catch (\Throwable $th) {
            DB::rollBack();
            // Log::error('User Creation Error: ' . $th->getMessage());
            SmartLog::throttledError('User Creation Error: ' . $th->getMessage(), [], 60);
            return response()->json(['message' => 'Failed to create user. Please try again.'], 500);
        }
    }

    // Update Page (Form) Get Karega with existing user data
    public function getUpdate(Request $request, $id = null)
    {
        $user = User::with('userInfo')->findOrFail($id ?? $request->id);
        $loginHistories = LoginHistory::where('user_id', $user->id)
                            ->orderBy('created_at', 'desc')
                            ->paginate(5); // Showing 5 rows per page
        return view('admin.users.update', compact('user', 'loginHistories'));
    }

    public function postUpdate(Request $request, $id)
    {
        // 1. Validation Logic
        $validator = Validator::make($request->all(), [
            'name'     => 'required|string|max:255',
            'username' => "required|string|max:255|unique:users,username,{$id}",
            'email'    => [ 'required', 'email',
                function ($attribute, $value, $fail) use ($id) {
                    $exists = User::where('email_hash', blind_hash($value))
                                ->where('id', '!=', $id) // Ignore current user
                                ->whereNull('deleted_at')
                                ->exists();
                    if ($exists) {
                        $fail('The email has already been taken.');
                    }
                }
            ],
            
            'profile_picture'  => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'cover_image'      => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'bio'              => 'nullable|string',
            'gender'           => 'nullable|in:male,female,other',
            'dob'              => 'nullable|date_format:d/m/Y',
            'location'         => 'nullable|string|max:255',
            'website'          => 'nullable|url',
            'work'             => 'nullable|string|max:255',
            'facebook_link'    => 'nullable|url',
            'instagram_link'   => 'nullable|url',
            'linkedin_link'    => 'nullable|url',
            'twitter_link'     => 'nullable|url',
            'interests'        => 'nullable|string',
            'education'        => 'nullable|string',
            // 'account_status'   => 'nullable|in:active,inactive,banned',
            
            'password' => [ 
                'nullable', 'confirmed',
                Password::min(8)->mixedCase()->numbers()->symbols(),
                'regex:/^\S*$/',
            ],
        ], [
            'password.regex' => 'The password should have a capital letter, a small letter, a special character and must not contain any spaces.'
        ]);
        
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        try {
            DB::beginTransaction();

            // A. Update Core User
            $user = User::findOrFail($id);
            $user->name      = $request->name;
            $user->email     = $request->email;
            $user->username  = $request->username;
            
            if ($request->has('email_verified_at')) {
                if (!$user->email_verified_at) {
                    $user->email_verified_at = now();
                }
            } else {
                $user->email_verified_at = null; 
            }
            
            if ($request->filled('password')) 
            { 
                $user->password = Hash::make($request->password);
            }
            $user->save();

            // B. Update UserInfo Profile
            $userInfo = UserInfo::firstOrNew(['user_id' => $user->id]);
            $userInfo->bio            = $request->bio;
            $userInfo->gender         = $request->gender;
            $userInfo->location       = $request->location;
            $userInfo->website        = $request->website;
            $userInfo->work           = $request->work;
            $userInfo->facebook_link  = $request->facebook_link;
            $userInfo->instagram_link = $request->instagram_link;
            $userInfo->linkedin_link  = $request->linkedin_link;
            $userInfo->twitter_link   = $request->twitter_link;
            // $userInfo->account_status = $request->account_status ?? 'active';
            
            $userInfo->is_private           = $request->has('is_private') ? true : false;
            $userInfo->is_verified          = $request->has('is_verified') ? true : false;
            $userInfo->interests            = $request->filled('interests') ? array_map('trim', explode(',', $request->interests)) : null;
            $userInfo->education            = $request->filled('education') ? array_map('trim', explode(',', $request->education)) : null;
            // $userInfo->email_verified_at    = $request->has('email_verified_at') ? true : false;
            
            // Carbon frontend ke DD/MM/YYYY ko pakad kar DB ke YYYY-MM-DD me convert karega
            if ($request->filled('dob')) {
                $dob = Carbon::createFromFormat('d/m/Y', $request->dob);
                // Age kam se kam 5 saal honi chahiye
                if ($dob->greaterThan(now()->subYears(5))) {
                    return response()->json(['message' => 'User must be at least 5 years old.'], 422);
                }
                // 1950 se pehle ka birth allow nahi hai
                if ($dob->year < 1950) {
                    return response()->json(['message' => 'Date of birth cannot be earlier than 1950.'], 422);
                }
                $userInfo->dob = $dob->format('Y-m-d');
            } else {
                $userInfo->dob = null;
            }

            // Handle Image Removals
            // 1. Profile Picture
            if ($request->remove_profile_picture == 1) {
                $oldFile = public_path("uploads/users/profile/profile_" . $user->id . ".webp");
                if (file_exists($oldFile)) @unlink($oldFile);
            }

            if ($request->hasFile('profile_picture')) {
                // NAME TO: profile_{user_id}.webp
                $profileImgName = 'profile_' . $user->id . '.webp';
                // Pass it as the 7th parameter
                uploadFile('profile_picture', 400, 400, 'users/profile', null, null, $profileImgName);
                $userInfo->profile_picture = null; // DB null hi rahega
            }

            // 2. Cover Image
            if ($request->remove_cover_image == 1) {
                $oldFile = public_path("uploads/users/cover/cover_" . $user->id . ".webp");
                if (file_exists($oldFile)) @unlink($oldFile);
            }

            if ($request->hasFile('cover_image')) {
                // FORCE THE NAME TO: cover_{user_id}.webp
                $coverImgName = 'cover_' . $user->id . '.webp';
                uploadFile('cover_image', 1200, 400, 'users/cover', null, null, $coverImgName);
                $userInfo->cover_image = null; 
            }

            $userInfo->save();

            DB::commit();

            // Redirect se pehle success session set karna
            session()->flash('success', 'User updated successfully.');

            return response()->json([
                'message' => 'Data updated successfully.',
                'redirect' => route('admin.users.list')
            ]);

        } catch (\Throwable $th) {
            DB::rollBack();
            // Log::error('User Update Error: ' . $th->getMessage());
            SmartLog::throttledError('User Update Error: ' . $th->getMessage(), [], 60);
            return response()->json(['message' => 'Failed to process your request. Please try again later.'], 500);
        }
    }
    
    public function destroy(Request $request, $id)
    {
        DB::beginTransaction();

        try {

            // throw new \Exception("Database connection lost intentionally for testing.");
            $user = User::with('userInfo')->findOrFail($id);

            // Agar user ki profile info exist karti hai
            if ($user->userInfo) {
                
                // Profile Picture delete
                if (!empty($user->userInfo->profile_picture) && $user->userInfo->profile_picture !== 'default.jpg') {
                    $profilePath = public_path("uploads/users/profile/" . $user->userInfo->profile_picture);
                    if (file_exists($profilePath)) {
                        @unlink($profilePath); // @ errors ko suppress karta hai agar file OS level par lock ho
                    }
                }

                // Cover Image delete
                if (!empty($user->userInfo->cover_image) && $user->userInfo->cover_image !== 'default.jpg') {
                    $coverPath = public_path("uploads/users/cover/" . $user->userInfo->cover_image);
                    if (file_exists($coverPath)) {
                        @unlink($coverPath);
                    }
                }

                // C. UserInfo data permanently delete
                $user->userInfo()->delete();
            }

            // Main user delete
            $user->delete();

            DB::commit();
            return redirect()->back()->with('success', 'User deleted successfully.');

        } catch (\Exception $e) {

            DB::rollBack();
            // Log::error('User Deletion Failed: ' . $e->getMessage());
            SmartLog::throttledError('User Deletion Failed: ' . $e->getMessage(), [], 60);

            return redirect()->back()->with('error', 'Failed to delete user. Please try again.');
        }
    }

    // public function getDelete(Request $request, $id = null)
    // {
    //     // ID request se ya URL parameter se get
    //     $userId = $id ?? $request->id;
    //     $user = User::with('userInfo')->findOrFail($userId);

    //     // Agar user ki profile info exist karti hai
    //     if ($user->userInfo) {
            
    //         // 1. Profile Picture ko public/uploads folder se delete
    //         if (!empty($user->userInfo->profile_picture) && $user->userInfo->profile_picture !== 'default.jpg') {
    //             $profilePath = public_path("uploads/users/profile/" . $user->userInfo->profile_picture);
    //             if (file_exists($profilePath)) {
    //                 unlink($profilePath);
    //             }
    //         }

    //         // 2. Cover Image ko public/uploads folder se delete
    //         if (!empty($user->userInfo->cover_image) && $user->userInfo->cover_image !== 'default.jpg') {
    //             $coverPath = public_path("uploads/users/cover/" . $user->userInfo->cover_image);
    //             if (file_exists($coverPath)) {
    //                 unlink($coverPath);
    //             }
    //         }

    //         // 3. UserInfo table se user ka pura data permanently (hard) delete
    //         $user->userInfo()->delete();
    //     }

    //     $user->delete();

    //     // JSON response ki jagah wapas list page par redirect karenge with success message
    //     return redirect()->back()->with('success', 'User deleted successfully.');
    // }
}