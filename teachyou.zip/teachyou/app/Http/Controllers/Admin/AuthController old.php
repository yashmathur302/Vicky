<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\RateLimiter;
use App\Http\Requests\AdminLoginRequest;
use \App\Mail\AdminPasswordResetMail;

class AuthController extends Controller
{
    //Show the login page
    public function getLogin()
    {
        // If user is already logged in, bypass the login page
        // if (Auth::check()) {
        //     return redirect()->route('admin.dashboard');
        // }

        return view('admin.auth.login');
    }

    public function postLogin(AdminLoginRequest $request)
    {
        $validator = Validator::make($request->all(), [
            'login_id' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        // 1. Create a unique rate limiting key based on Login ID and IP Address
        $throttleKey = Str::lower($request->login_id) . '|' . $request->ip();

        // 2. Check if the user has exceeded max attempts (e.g., 5 attempts)
        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);
            // Testing ke liye: 60 seconds (1 minute). Production ke liye: $seconds ko hours me convert karke dikhayein ya RateLimiter::hit me duration badhayein
            return response()->json([
                'message' => "Too many login attempts. Please try again in {$seconds} seconds."
            ], 429);
        }

        // Identify Input Type (Check karna ki input Email format me hai ya Username format me)
        $loginType = filter_var($request->login_id, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';

        $credentials = [
            $loginType => $request->login_id,
            'password' => $request->password
        ];
        $remember = $request->has('remember');

        if (Auth::attempt($credentials, $remember)) {
            $user = Auth::user();

            // Sirf admin user hi login karega
            if ($user->user_role !== 'admin') {
                Auth::logout();
                // Failed login for non-admin, hit the rate limiter
                RateLimiter::hit($throttleKey, 60); // 1800 for 5 hours
                return response()->json(['message' => 'Unauthorized access. Only admins can log in here.'], 401);
            }

            // 3. Clear the rate limiter on successful login
            RateLimiter::clear($throttleKey);

            return response()->json([
                'message'  => 'Authentication successful. Redirecting...',
                'redirect' => route('admin.dashboard')
            ]);
        }

        // 4. Hit the rate limiter on failed login attempt
        RateLimiter::hit($throttleKey, 60); // 60 seconds lockout duration (Change to 18000 for 5 hours in production)
        
        // Optionally, calculate remaining attempts to warn the user
        $retriesLeft = RateLimiter::retriesLeft($throttleKey, 5);

        return response()->json(['message' => "Invalid credentials. You have {$retriesLeft} attempts left."], 401);
    }

    //Handle Admin Logout
    public function postLogout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect()->route('admin.login.index');
    }

    // Show the Forgot Password Page
    public function getForgotPassword()
    {
        return view('admin.auth.forgot-password');
    }

    public function postForgotPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        $throttleKey = 'forgot-password|' . $request->ip();
        if (RateLimiter::tooManyAttempts($throttleKey, 3)) {

        $seconds = RateLimiter::availableIn($throttleKey);

            return response()->json([
                'message' => 'Too many requests.',
                'locked_seconds' => $seconds
            ], 429);
        }

        // Check if user exists and is actually an admin
        $user = User::where('email', $request->email)->where('user_role', 'admin')->first();

        if ($user) {
            // Generate plain token for Email URL
            $token = Str::random(64);

            // --- NEW: SECURE TOKEN STORAGE (Hashing) ---
            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $request->email],
                [
                    'token' => Hash::make($token), // Hashed in DB!
                    'created_at' => Carbon::now()
                ]
            );

            try {
                Mail::to($request->email)->send(new AdminPasswordResetMail($token, $request->email));
            } catch (\Throwable $e) {
                Log::error('Mail Sending Failed: ' . $e->getMessage());
            }
        }

        // Hit Rate Limiter (Lock for 30 seconds after 3 attempts)
        RateLimiter::hit($throttleKey, 60);

        return response()->json([
            'message'  => "If this email is correct, you'll get the reset link.",
            'redirect' => route('admin.login.index')
        ]);
    }

    //Show the Password Reset Form
    public function getResetPassword(Request $request, $token)
    {
        $email = $request->email;
        $tokenData = DB::table('password_reset_tokens')->where('email', $email)->first();

        // Yahan hum Check kar rahe hain ki Token DB me hai, uski Hash match hoti hai, aur wo 60 seconds ke andar hai.
        if (!$tokenData || !Hash::check($token, $tokenData->token) || Carbon::parse($tokenData->created_at)->addSeconds(60)->isPast()) {
            
            // Redirecting to Forgot Password with a clear message
            return redirect()->route('admin.forgot.password.index')->with('error', 'The password reset link has expired or is invalid. Please request a new one.');
        }

        return view('admin.auth.reset-password', compact('token', 'email'));
    }

    //Process the New Password Submission
    public function postResetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email'    => 'required|email',
            'token'    => 'required|string',
            'password' => ['required', 'confirmed', Password::min(8)->mixedCase()->numbers()->symbols(),'regex:/^\S*$/', ],
        ], ['password.regex' => 'The password must not contain any spaces.']);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        // Validate Token & Expiration again on POST
        $resetRecord = DB::table('password_reset_tokens')->where('email', $request->email)->first();

        if (!$resetRecord || !Hash::check($request->token, $resetRecord->token) || Carbon::parse($resetRecord->created_at)->addMinutes(15)->isPast()) {
            return response()->json([
                'message' => 'Your session has expired. Please request a new link.',
                'redirect' => route('admin.forgot.password.index') 
            ], 422);
        }

        // $resetRecord = DB::table('password_reset_tokens')->where('email', $request->email)->first();

        // if (!$resetRecord || !Hash::check($request->token, $resetRecord->token) || Carbon::parse($resetRecord->created_at)->addSeconds(60)->isPast()) {
        //     // Frontend ko wapas Forgot Password par bhejne ka response
        //     return response()->json([
        //         'message' => 'Your session has expired. Please request a new link.',
        //         'redirect' => route('admin.forgot.password.index')
        //     ], 422);
        // }

        try {
            $user = User::where('email', $request->email)->first();
            
            if ($user) {
                // Protect against Password Reuse
                if (Hash::check($request->password, $user->password)) {
                    return response()->json([
                        'message' => 'Your new password cannot be exactly the same as your current password.'
                    ], 422);
                }

                $user->password = Hash::make($request->password);
                $user->save();
            }

            // Naya password set hote hi token delete ho jayega, ab is link ko dobara use nahi kiya ja sakta
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();

            return response()->json([
                'message' => 'Password reset successfully! Redirecting...',
                'redirect' => route('admin.login.index')
            ]);

        } catch (\Exception $e) {
            Log::error('Password Reset Error: ' . $e->getMessage());
            return response()->json(['message' => 'Something went wrong. Please try again.'], 500);
        }
    }
}