<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\RateLimiter;
use App\Http\Requests\AdminLoginRequest;
use App\Http\Requests\AdminForgotPasswordRequest;
use App\Http\Requests\AdminResetPasswordRequest;
use \App\Mail\AdminPasswordResetMail;
use App\Support\SmartLog;

class AuthController extends Controller
{
    //Show the login page
    public function getLogin()
    {
        return view('admin.auth.login');
    }

    public function postLogin(AdminLoginRequest $request)
    {
        $request->authenticate();

        // Session ko regenerate karna hamesha best practice hai
        $request->session()->regenerate();

        return response()->json([
            'message'  => 'Authentication successful. Redirecting...',
            'redirect' => route('admin.dashboard')
        ]);
    }

    //Handle Admin Logout
    public function postLogout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect()->route('admin.login.index');
    }

    // Show the Forgot Password Page
    public function getForgotPassword()
    {
        return view('admin.auth.forgot-password');
    }

    public function postForgotPassword(AdminForgotPasswordRequest $request)
    {
        // Rate Limiting Check
        $request->ensureIsNotRateLimited();

        // Business Logic
        $user = User::where('email_hash', blind_hash($request->email))->first();
        // $user = User::where('email', $request->email)->where('user_role', 'admin')->first();

        if ($user) {
            $token = Str::random(64);

            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $request->email],
                [
                    'token' => Hash::make($token), 
                    'created_at' => Carbon::now()
                ]
            );

            try {
                Mail::to($request->email)->send(new AdminPasswordResetMail($token, $request->email, $user->name));
            } catch (\Throwable $th) {
                // Log::error('Mail Sending Failed: ' . $th->getMessage());
                SmartLog::throttledError('Mail Sending Failed: ' . $th->getMessage(), [], 60);
                
            }
        }

        // 4. Register Rate Limit Hit
        $request->hitRateLimiter();

        return response()->json([
            'message'  => "If this email is correct, you'll get the reset link.",
            'redirect' => route('admin.login.index')
        ]);
    }

    //Show the Password Reset Form
    public function getResetPassword(Request $request, string $token)
    {
        $email = $request->email;
        $tokenData = DB::table('password_reset_tokens')->where('email', $email)->first();

        // Check kar rahe hain ki Token DB me hai, uski Hash match hoti hai, aur wo 60 seconds ke andar hai.
        if (!$tokenData || !Hash::check($token, $tokenData->token) || Carbon::parse($tokenData->created_at)->addSeconds(60)->isPast()) {
            return redirect()->route('admin.forgot.password.index')->with('error', 'The password reset link has expired or is invalid. Please request a new one.');
        }

        return view('admin.auth.reset-password', compact('token', 'email'));
    }

    //Process the New Password Submission
    public function postResetPassword(AdminResetPasswordRequest $request)
    {
        // Validation automatically passed
        $resetRecord = DB::table('password_reset_tokens')->where('email', $request->email)->first();

        if (!$resetRecord || !Hash::check($request->token, $resetRecord->token) || Carbon::parse($resetRecord->created_at)->addMinutes(15)->isPast()) {
            return response()->json([
                'message' => 'Your session has expired. Please request a new link.',
                'redirect' => route('admin.forgot.password.index') 
            ], 422);
        }

        try {
            // $user = User::where('email', $request->email)->first();

            // Find user using the deterministic hash
            $user = User::where('email_hash', blind_hash($request->email))->first();
            
            if ($user) {
                if (Hash::check($request->password, $user->password)) {
                    return response()->json([ 'message' => 'Your new password cannot be exactly the same as your current password.'], 422);
                }
                $user->password = Hash::make($request->password);
                $user->save();
            }
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();

            return response()->json([
                'message' => 'Password reset successfully! Redirecting...',
                'redirect' => route('admin.login.index')
            ]);

        } catch (\Exception $e) {
            Log::error('Password Reset Error: ' . $e->getMessage());
                // SmartLog::throttledError('Password Reset Error: ' . $th->getMessage(), [], 60);

            return response()->json(['message' => 'Something went wrong. Please try again.'], 500);
        }
    }
}