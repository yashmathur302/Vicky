<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Support\SmartLog;

use App\Models\Category;

class EventController extends Controller
{
    // Events List Page Show Karega (With AJAX Filtering)
    public function getList(Request $request)
    {
        // with() ka use karke relation ka data ek hi query me la rahe hain optimization ke liye
        $query = Event::with(['creator', 'category'])->orderBy('created_at', 'desc');

        // Filters
        if ($request->filled('search_title')) {
            $query->where('title', 'like', '%' . $request->search_title . '%');
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        $events = $query->paginate(15);
        $categories = Category::where('status', 'active')->get(); // Dropdown ke liye

        return view('admin.events.list', compact('events', 'categories'));
    }

    // Update Page (Form) Get Karega
    public function getUpdate(Request $request, $id)
    {
        $event = Event::findOrFail($id);
        $categories = Category::where('status', 'active')->get(); // Dropdown
        $users = User::where('id', $event->user_id)->get();  // fetching only the creator of event

        //fetching all users
        // $users = User::whereNull('deleted_at')->orderBy('name', 'asc')->get();

        
        return view('admin.events.update', compact('event', 'categories', 'users'));
    }

    // Event Update Database Save Karega (AJAX)
    public function postUpdate(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'user_id'       => 'required|exists:users,id',
            'title'         => 'required|string|max:255',
            'category_id'   => 'nullable|exists:categories,id',
            'privacy_level' => 'required|in:public,private,friends',
            'location_name' => 'nullable|string|max:255',

            'start_date'    => 'required|date_format:d/m/Y',
            'start_time'    => 'required|date_format:H:i',
            'end_date'      => 'nullable|date_format:d/m/Y',
            'end_time'      => 'nullable|required_with:end_date|date_format:H:i',
            'description'   => 'nullable|string',
            'cover_image'   => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'status'        => 'required|in:scheduled,ongoing,completed,cancelled',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        try {
            DB::beginTransaction();

            $event = Event::findOrFail($id);
            $event->user_id       = $request->user_id;
            $event->title         = $request->title;
            $event->category_id   = $request->category_id;
            $event->privacy_level = $request->privacy_level;
            $event->status        = $request->status;
            $event->location_name = $request->location_name;
            $event->start_at      = $request->start_at;
            $event->end_at        = $request->end_at;
            $event->description   = $request->description;

            $startAtString = $request->start_date . ' ' . $request->start_time;
            $startAt = Carbon::createFromFormat('d/m/Y H:i', $startAtString);
            
            // (Humne != check isliye lagaya hai kyunki agar purana event hai jo past me shuru ho chuka hai, aur admin sirf uska title update kar raha hai, to wo pass ho jana chahiye)
            if ($startAt->isPast() && $startAt->format('Y-m-d H:i') != $event->start_at->format('Y-m-d H:i')) {
                return response()->json(['message' => 'New event start time cannot be set in the past.'], 422);
            }
            
            $event->start_at = $startAt->format('Y-m-d H:i:s');

            if ($request->filled('end_date') && $request->filled('end_time')) {
                $endAtString = $request->end_date . ' ' . $request->end_time;
                $endAt = Carbon::createFromFormat('d/m/Y H:i', $endAtString);
                
                // Check 2: End Date/Time MUST be strictly greater than Start Date/Time
                if ($endAt->lessThanOrEqualTo($startAt)) {
                    return response()->json(['message' => 'Event End Time must be strictly after the Start Time.'], 422);
                }
                
                $event->end_at = $endAt->format('Y-m-d H:i:s');
            } else {
                $event->end_at = null;
            }

            // Image Removal Logic
            if ($request->remove_cover_image == 1) {
                if ($event->cover_image) {
                    $oldFile = public_path("uploads/events/cover/" . $event->cover_image);
                    if (file_exists($oldFile)) {
                        unlink($oldFile);
                    }
                }
                $event->cover_image = null; 
            }

            // Image Upload Logic (Using your existing uploadFile helper)
            if ($request->hasFile('cover_image')) {
                // Resize parameters events ke liye set kiye hain (e.g., 1200x600 for wide cover)
                $coverImgName = uploadFile('cover_image', null, null, 'events/cover', $event->cover_image);
                if ($coverImgName) {
                    $event->cover_image = $coverImgName;
                }
            }

            $event->save();

            DB::commit();

            session()->flash('success', 'Event updated successfully.');
            return response()->json([
                'message' => 'Event updated successfully.',
                'redirect' => route('admin.events.list') 
            ]);

        } catch (\Throwable $th) {
            DB::rollBack();
            // Log::error('Event Update Error: ' . $th->getMessage());
            SmartLog::throttledError('Event Update Error: ' . $th->getMessage(), [], 60);

            return response()->json(['message' => 'Failed to process your request. Please try again later.'], 500);
        }
    }

    public function destroy(Request $request, $id = null)
    {
        DB::beginTransaction();

        try {
            $event = Event::findOrFail($id);
            // if (!empty($event->cover_image) && $event->cover_image !== 'default.jpg') {
            //     $profilePath = public_path("uploads/events/cover/" . $event->cover_image);
            //     if (file_exists($profilePath)) {
            //         unlink($profilePath);
            //     }
            // }
            $event->delete();
            DB::commit();
            return redirect()->back()->with('success', 'Event deleted successfully.');

        } catch (\Throwable $th) {
            DB::rollBack();
            // Log::error('Event Deletion Failed: ' . $e->getMessage());
            SmartLog::throttledError('Event Deletion Failed: ' . $th->getMessage(), [], 60);
            return redirect()->back()->with('error', 'Failed to delete event. Please try again.');
        }
    }

    // Event Delete Karega
    // public function getDelete(Request $request, $id)
    // {
    //     try {
    //         $event = Event::findOrFail($id);
    //         $event->delete();

    //         return redirect()->route('admin.events.list')->with('success', 'Event deleted successfully.');
    //     } catch (\Throwable $th) {
    //         Log::error('Event Delete Error: ' . $th->getMessage());
    //         return redirect()->route('admin.events.list')->with('error', 'Failed to delete event.');
    //     }
    // }
}