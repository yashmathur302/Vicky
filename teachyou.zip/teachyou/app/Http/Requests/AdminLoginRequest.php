<?php

namespace App\Http\Requests;

use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Hash;
use \App\Models\User;

class AdminLoginRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'login_id' => ['required', 'string'],
            'password' => ['required', 'string'],
        ];
    }

    public function authenticate(): void
    {
        $this->ensureIsNotRateLimited();

        $loginId = $this->login_id;
        $isEmail = filter_var($loginId, FILTER_VALIDATE_EMAIL);

        // --- ENCRYPTION SAFE LOGIN LOGIC ---
        if ($isEmail) {
            // Agar email hai, toh hash generate karke DB me exact match dhoondho
            $user = User::where('email_hash', blind_hash($loginId))
                        ->where('user_role', 'admin')
                        ->first();
        } else {
            // Agar username hai, toh direct match karo (kyunki username plain text hai)
            $user = User::where('username', $loginId)
                        ->where('user_role', 'admin')
                        ->first();
        }

        // Agar user nahi mila YA password match nahi hua
        if (! $user || ! Hash::check($this->password, $user->password)) {
            
            // DUAL HIT: Dono par strike lagao
            RateLimiter::hit($this->ipKey(), 60); 
            RateLimiter::hit($this->emailKey(), 60); 

            $retriesLeft = min(
                RateLimiter::retriesLeft($this->ipKey(), 10),
                RateLimiter::retriesLeft($this->emailKey(), 5)
            );

            $errorMessage = trans('auth.failed');
            if ($retriesLeft > 0) {
                $errorMessage .= " You have {$retriesLeft} attempts left.";
            }

            throw ValidationException::withMessages([
                'login_id' => $errorMessage,
            ]);
        }

        // Login success par manual authentication
        Auth::login($user, $this->boolean('remember'));
        
        RateLimiter::clear($this->ipKey());
        RateLimiter::clear($this->emailKey());
    }

    public function ensureIsNotRateLimited(): void
    {
        // DUAL CHECK: Agar Email par 5 strikes ho gaye YA IP par 10 strikes ho gaye
        if (RateLimiter::tooManyAttempts($this->emailKey(), 4) || RateLimiter::tooManyAttempts($this->ipKey(), 4)) {
            
            event(new Lockout($this));

            // Jo bhi limit zyada der me khulegi, uske seconds nikal lo
            $seconds = max(
                RateLimiter::availableIn($this->emailKey()),
                RateLimiter::availableIn($this->ipKey())
            );

            throw new HttpResponseException(response()->json([
                'message' => 'Too many login attempts.',
                'locked_seconds' => $seconds
            ], 429));
        }
    }

    // NAYA: Do alag-alag keys banayi hain
    protected function emailKey(): string
    {
        return 'login-email|' . Str::lower($this->input('login_id'));
    }

    protected function ipKey(): string
    {
        return 'login-ip|' . $this->ip();
    }
}