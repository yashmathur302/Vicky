<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\UserInfo;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run()
    {
        // 1. Create Admin in Users Table
        //'email' ki jagah 'username' se search kar rahe hain kyunki username plain text hai
        $admin = User::updateOrCreate(
            ['username' => 'Admin@123'], // Search parameter
            [
                'name' => 'Admin',
                'email' => 'vicky@compuhost.co.in', // Laravel will automatically encrypt this & Model Boot will hash it
                'password' => Hash::make('Admin@123'),
                'user_role' => 'admin',
            ]
        );

        // 2. Create Profile entry in UserInfos Table
        UserInfo::updateOrCreate(
            ['user_id' => $admin->id],
            [
                'account_status' => 'active',
                'is_verified' => true,
            ]
        );
    }
}