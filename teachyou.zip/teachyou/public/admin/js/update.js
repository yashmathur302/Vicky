
$(document).ready(function() {

    //Event Update JS - AJAX Form Submission
    $('#updateEventForm').on('submit', function(e) {
        e.preventDefault(); 
        
        let form = $(this);
        let submitBtn = $('#submitBtn'); 
        let formData = new FormData(this);

        let sDate = formData.get('start_date');
        let eDate = formData.get('end_date');
        let sTime = formData.get('start_time');
        let eTime = formData.get('end_time');

        // --- SMART TIME VALIDATION --- //
        if (eDate && !eTime) {
            showToastMessage('error', "Please provide an end time if you have selected an end date.");
            return false; 
        }

        if (sDate && eDate && (sDate === eDate)) {
            if (sTime && eTime && (eTime <= sTime)) {
                showToastMessage('error', "Event end time is incorrect. It cannot end before or exactly when it starts on the same day.");
                return false; 
            }
        }

        // Processing state
        submitBtn.prop('disabled', true).text('Updating...');

        $.ajax({
            url: form.attr('action'),
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if(response.redirect) { 
                    window.location.href = response.redirect; 
                }
            },
            error: function(xhr) {
                submitBtn.prop('disabled', false).text('Update Event'); 
                
                if(xhr.status === 422) {
                    showToastMessage('error', xhr.responseJSON.message);
                } else {
                    showToastMessage('error', 'Something went wrong. Please try again.');
                }
            }
        });
    });

    //Users Update JS
    if ($('#updateUserForm').length) {
        
        let tagifyInterests, tagifyEducation;

        // Initialize Tagify (Only if fields exist)
        if (document.querySelector('#interests')) {
            tagifyInterests = new Tagify(document.querySelector('#interests'), {
                originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(','),
                addTagOnBlur: false 
            });
        }
        
        if (document.querySelector('#education')) {
            tagifyEducation = new Tagify(document.querySelector('#education'), {
                originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(','),
                addTagOnBlur: false 
            });
        }

        // AJAX Submission
        $('#updateUserForm').on('submit', function(e) {
            e.preventDefault(); 

            // SMART TAGIFY FIX: Agar user ne type kiya par enter nahi dabaya, to automatically usko tag bana do!
            if (tagifyInterests && tagifyInterests.state.inputText) {
                tagifyInterests.addTags(tagifyInterests.state.inputText);
            }
            if (tagifyEducation && tagifyEducation.state.inputText) {
                tagifyEducation.addTags(tagifyEducation.state.inputText);
            }

            let form = $(this);
            let submitBtn = $('#submitBtn');
            let formData = new FormData(this);

            submitBtn.prop('disabled', true).text('Updating...');

            $.ajax({
                url: form.attr('action'),
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    if(response.redirect) {
                        window.location.href = response.redirect;
                    }
                },
                error: function(xhr) {
                    submitBtn.prop('disabled', false).text('Update');
                    if(xhr.status === 422) {
                        showToastMessage('error', xhr.responseJSON.message);
                    } else {
                        showToastMessage('error', 'Something went wrong. Please try again.');
                    }
                }
            });
        });
    }
});