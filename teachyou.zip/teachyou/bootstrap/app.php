<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Session\Middleware\AuthenticateSession;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
            web: [
                __DIR__.'/../routes/web.php',
                __DIR__.'/../routes/frontend.php',
            ],
            commands: __DIR__.'/../routes/console.php',
            health: '/up',
        )
    ->withMiddleware(function (Middleware $middleware) 
    { $middleware->web(append: [AuthenticateSession::class]); })

    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
