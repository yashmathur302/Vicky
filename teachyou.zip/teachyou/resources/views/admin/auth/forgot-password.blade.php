@extends('layouts.admin.auth')

@section('title', 'Forgot Password')

@section('content')
<div class="card login-card">
    <div class="card-header text-center pt-4 pb-3 border-0">
        <!-- Logo -->
        <img src="{{ asset('admin/img/logo2.svg') }}" alt="Logo" height="35" class="mb-3">
        <h3 class="card-title fw-bold">Forgot Password</h3>
        <p class="text-muted mb-0">Enter your email to receive a password reset link.</p>
    </div>
    <div class="card-body p-4">

        <!-- Display Session Errors (like Expired Token) -->
        @if(session('error'))
            <div class="alert alert-danger text-center small fw-bold">
                <i class="fas fa-exclamation-triangle"></i> {{ session('error') }}
            </div>
        @endif
        
        <!-- Forgot Password Form -->
        <form id="forgotPasswordForm" action="{{ route('admin.forgot.password') }}" method="POST">
            @csrf
            <div class="form-group px-0 pt-0">
                <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required autofocus>
                </div>
            </div>
            <div class="form-action mb-3 mt-4">
                <button type="submit" id="resetBtn" class="btn btn-primary w-100 btn-round fw-bold">Send Reset Link</button>
            </div>
            <div class="text-center mt-3">
                <a href="{{ route('admin.login.index') }}" class="text-primary small fw-bold">Back to Sign In</a>
            </div>
        </form>
        <!-- Message Display Container -->
        <div id="resetMessage" class="mt-3 text-center" style="display: none;"></div>

    </div>
</div>
@endsection

{{-- @push('scripts')
    <script>
        $(document).ready(function() {
            let countdownInterval = null; // Timer variable define kiya

            $('#forgotPasswordForm').on('submit', function(e) {
                e.preventDefault(); 
                
                let form = $(this);
                let submitBtn = $('#resetBtn');
                let messageBox = $('#resetMessage');
                let formData = form.serialize();

                // UI State: Submitting
                submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Sending...');
                messageBox.slideUp().removeClass('text-danger text-success');

                // Purana koi timer chal raha ho to clear kar dein
                if (countdownInterval) {
                    clearInterval(countdownInterval);
                }

                $.ajax({
                    url: form.attr('action'),
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        // UI State: Success
                        submitBtn.removeClass('btn-primary').addClass('btn-success').html('<i class="fas fa-check"></i> Link Sent');
                        messageBox.html('<small class="fw-bold text-success">' + response.message + '</small>').slideDown();
                        
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    },
                    error: function(xhr) {
                        // 1. RATE LIMIT LOCKOUT (Status 429)
                        if (xhr.status === 429) {
                            let secondsLeft = xhr.responseJSON.locked_seconds;

                            submitBtn.prop('disabled', true).html('<i class="fas fa-lock"></i> Locked');
                            
                            messageBox.html('<small class="fw-bold text-danger"><i class="fas fa-ban"></i> Too many requests. Try again in <span id="timerText">' + secondsLeft + '</span> seconds.</small>').slideDown();

                            // Countdown Timer shuru karein
                            countdownInterval = setInterval(function() {
                                secondsLeft--;
                                $('#timerText').text(secondsLeft);

                                if (secondsLeft <= 0) {
                                    clearInterval(countdownInterval);
                                    submitBtn.prop('disabled', false).html('Send Reset Link');
                                    messageBox.slideUp();
                                }
                            }, 1000);

                            return; // Yahan se rok do taaki niche ke errors na chalein
                        }
                        
                        // 2. NORMAL VALIDATION ERROR (Status 422)
                        else if (xhr.status === 422) {
                            submitBtn.prop('disabled', false).html('Send Reset Link');
                            let errorMsg = xhr.responseJSON.message;
                            messageBox.html('<small class="fw-bold text-danger"><i class="fas fa-exclamation-circle"></i> ' + errorMsg + '</small>').slideDown();
                        } 
                        
                        // 3. SERVER CRASH OR OTHER ERROR
                        else {
                            submitBtn.prop('disabled', false).html('Send Reset Link');
                            messageBox.html('<small class="fw-bold text-danger"><i class="fas fa-exclamation-triangle"></i> An error occurred. Please try again.</small>').slideDown();
                        }
                    }
                });
            });
        });
    </script>
@endpush --}}