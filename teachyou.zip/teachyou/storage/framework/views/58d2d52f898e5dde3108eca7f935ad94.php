<footer class="footer py-2 px-4 text-muted fs-8">
  <div class="container-fluid d-flex justify-content-between">
    <nav class="pull-left">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link text-muted" href="#">
            Help
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright">
      <?php echo e(date('Y')); ?>, 
      
      Developed by <a class="text-decoration-none" href="https://compuhost.co.in/">Compushost</a>
    </div>
  </div>
</footer><?php /**PATH D:\Projects\teachyou\resources\views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>