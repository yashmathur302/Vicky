

<?php $__env->startSection('title', 'My Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <!-- Header -->
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-3 px-4">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-user-shield me-2"></i> User Profile Details</h5>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-light text-danger fw-bold rounded-pill px-3">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </form>
                </div>

                <!-- Body -->
                <div class="card-body p-4 p-md-5">
                    
                    <div class="alert alert-success d-flex align-items-center mb-4 rounded-3" role="alert">
                        <i class="fas fa-check-circle fs-4 me-3"></i>
                        <div>
                            <strong>Login Successful!</strong> Welcome back, <strong><?php echo e($user->name); ?></strong>. 
                            <br><small>Below is your securely decrypted session and device data.</small>
                        </div>
                    </div>

                    <h6 class="fw-bold text-muted text-uppercase mb-3">Account & Security Information</h6>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <tbody>
                                <tr>
                                    <th width="35%" class="bg-light text-secondary"><i class="fas fa-id-card me-2"></i> Full Name</th>
                                    <td class="fw-bold"><?php echo e($user->name); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-user-tag me-2"></i> Username</th>
                                    <td><?php echo e($user->username); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-envelope me-2"></i> Email Address</th>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-network-wired me-2"></i> IP Address</th>
                                    <td>
                                        <span class="badge bg-dark px-2 py-1"><?php echo e($user->ip_address ?? 'Not Detected'); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-laptop me-2"></i> Operating System</th>
                                    <td><?php echo e($user->operating_system ?? 'Not Detected'); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-globe me-2"></i> Browser</th>
                                    <td><?php echo e($user->browser ?? 'Not Detected'); ?></td>
                                </tr>
                                <tr>
                                    <th class="bg-light text-secondary"><i class="fas fa-clock me-2"></i> Last Login</th>
                                    <td>
                                        <?php if($user->last_login): ?>
                                            <span class="text-primary fw-bold"><?php echo e($user->last_login->format('d M Y, h:i A')); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted fst-italic">No record found</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
            
            <div class="text-center mt-4">
                <p class="text-muted small"><i class="fas fa-lock"></i> Secured by AES-256 Encryption Database Casts</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\teachyou\resources\views/frontend/home.blade.php ENDPATH**/ ?>