

<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-card">
    <div class="auth-header">
        <h3>Welcome Back!</h3>
        <p class="text-muted small mb-0">Sign in to continue to your dashboard.</p>
    </div>
    <div class="auth-body">
        <form id="frontendLoginForm" action="<?php echo e(route('login.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
                <label for="login_id" class="form-label fw-bold small">Email or Username <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" id="login_id" name="login_id" placeholder="Enter email or username" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label for="password" class="form-label fw-bold small mb-0">Password <span class="text-danger">*</span></label>
                    <a href="#" class="text-decoration-none small">Forgot Password?</a>
                </div>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                    <span class="input-group-text password-toggle"><i class="fas fa-eye"></i></span>
                </div>
            </div>

            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" id="remember" name="remember">
                <label class="form-check-label small" for="remember">
                    Remember me
                </label>
            </div>

            <!-- Message Container for AJAX Responses -->
            <div class="form-message mt-2" style="display: none;"></div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary w-100">Sign In</button>
            </div>
            
            <div class="text-center mt-3 small">
                Don't have an account? <a href="<?php echo e(route('register')); ?>" class="text-decoration-none fw-bold">Sign Up</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\teachyou\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>