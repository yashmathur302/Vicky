

<?php $__env->startSection('title', 'Sign In'); ?>

<?php $__env->startSection('content'); ?>
<div class="card login-card">
    <div class="card-header text-center pt-4 pb-3 border-0">
        <!-- Logo -->
        <img src="<?php echo e(asset('admin/img/logo2.svg')); ?>" alt="Logo" height="35" class="mb-3">
        <h3 class="card-title fw-bold">Admin Sign In</h3>
    </div>
    <div class="card-body p-4">
        
        <!-- Login Form -->
        <form id="adminLoginForm" action="<?php echo e(route('admin.login')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group px-0 pt-0">
                <label for="login_id" class="form-label">Email or Username <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" id="login_id" name="login_id" placeholder="Enter your email or username" required autofocus>
                </div>
            </div>

            <div class="form-group px-0">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label for="password" class="form-label mb-0">Password <span class="text-danger">*</span></label>
                    <a href="<?php echo e(route('admin.forgot.password.index')); ?>" class="text-primary small">Forgot Password?</a>
                </div>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                    <!-- Eye Icon Toggle -->
                    <span class="input-group-text" id="togglePassword" style="cursor: pointer;">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
            </div>

            <div class="form-check px-0 mt-2 mb-3">
                <input class="form-check-input" type="checkbox" id="remember" name="remember">
                <label class="form-check-label" for="remember">
                    Remember Me
                </label>
            </div>

            <div class="form-action mb-3">
                <button type="submit" id="loginBtn" class="btn btn-primary w-100 btn-round fw-bold">Sign In</button>
            </div>
        </form>

        <!-- Message Display Container -->
        <div id="loginMessage" class="mt-3 text-center" style="display: none;"></div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\teachyou\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>