

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h3 class="fw-bold mb-3">Users</h3>
    <ul class="breadcrumbs mb-3">
        <li class="nav-home">
            <a href="<?php echo e(route('admin.users.list')); ?>">
                <i class="fas fa-home"></i>
            </a>
        </li>
        <li class="separator"><i class="fas fa-angle-right"></i></li>
        <li class="nav-item"><a href="#">Users</a></li>
        <li class="separator"><i class="fas fa-angle-right"></i></li>
        <li class="nav-item"><a href="#">Users List</a></li>
    </ul>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card card-round">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">All Users</h4>
                    <a href="javascript:void(0);" class="btn btn-primary btn-round ms-auto" data-bs-toggle="modal" data-bs-target="#createUserModal">
                        <i class="fa fa-plus"></i> Add New User
                    </a>
                </div>
            </div>
            
            <div class="card-body">

                <!-- FILTERS SECTION -->
                <div class="row g-3 mb-4" id="users-filters-container" data-url="<?php echo e(route('admin.users.list')); ?>">
                    <div class="col">
                        <input type="text" id="search_name" class="form-control filter-input" placeholder="Search by Name...">
                    </div>
                    <div class="col">
                        <input type="text" id="search_username" class="form-control filter-input" placeholder="Search by Username...">
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead class="thead-light">
                            <tr>
                                <th>S.no</th>
                                
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <!-- TBODY ko ek ID di hai taaki AJAX se ise replace kiya ja sake -->
                        <tbody id="user-table-body">
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="user-row-<?php echo e($user->id); ?>">
                                    <td><?php echo e($users->firstItem() + $key); ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo e($user->name); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo e($user->username); ?></div>
                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td class="text-center">
                                        <div class="form-button-action">
                                            <a href="<?php echo e(route('admin.users.update.index', $user->id)); ?>" data-bs-toggle="tooltip" title="Edit User" class="btn btn-link">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <a href="javascript:void(0);" onclick="confirmGlobalDelete('<?php echo e(route('admin.users.delete', $user->id)); ?>')" data-bs-toggle="tooltip" title="Delete User" class="btn btn-link">
                                                <i class="fa fa-trash text-danger"></i>
                                            </a>
                                            
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- PAGINATION ko ek ID di hai -->
                <div class="mt-4" id="pagination-container">
                    <?php echo e($users->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- create popup included -->
<?php echo $__env->make('admin.users.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('admin/js/list.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\teachyou\resources\views/admin/users/list.blade.php ENDPATH**/ ?>