<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e(config('app.name', 'Admin')); ?></title>
    <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
    
    <link rel="icon" href="<?php echo e(asset('admin/img/logo.svg')); ?>" type="image/x-icon" />

    <!-- Google Fonts: Public Sans -->
    
    
    
    
    <!-- ICONS (Replaced local fonts.min.css with CDNs) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
    
    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>" />
    
    <!-- Dynamic Page Styles -->
    <?php echo $__env->yieldPushContent('style'); ?>
  </head>
  <body>
    <div class="wrapper">
      
      <!-- Sidebar -->
      <?php echo $__env->make('layouts.admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      
      <div class="main-panel">
        
        <!-- Header / Topbar -->
        <?php echo $__env->make('layouts.admin.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content -->
        <div class="container">
          <div class="page-inner">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('layouts.admin.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/js/bootstrap-datepicker.min.js"></script>


    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('admin/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

    
    <!-- 1. Global Image Viewer Modal -->
    <div class="modal fade" id="globalImageViewerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Image Viewer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center p-4">
                    <img src="" id="globalViewerImage" class="img-fluid rounded shadow-sm" alt="View Image" style="max-height: 70vh; object-fit: contain;">
                </div>
            </div>
        </div>
    </div>

    
   <script>
        // 1. SWEETALERT TOAST NOTIFICATIONS (Replaces Bootstrap Alerts)
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });

        // Laravel Session Messages ko Toast me convert karna
        <?php if(session('success')): ?>
            Toast.fire({ icon: 'success', title: "<?php echo e(session('success')); ?>" });
        <?php endif; ?>
        <?php if(session('error')): ?>
            Toast.fire({ icon: 'error', title: "<?php echo e(session('error')); ?>" });
        <?php endif; ?>

        // Global AJAX Error Handler (For Toastr/SweetAlert in AJAX calls)
        function showToastMessage(type, message) {
            Toast.fire({ icon: type, title: message });
        }


        $(document).ready(function() {

            // image dropify JS
            if ($.fn.dropify) {
                $('.dropify').dropify({
                    error: {
                        'fileSize': 'The file size is too big (4M max).',
                        'imageFormat': 'The image format is not allowed (webp, png, jpg, jpeg).'
                    }
                }).on('dropify.afterClear', function(event, element) {
                    // Automatically hidden field dhoondh kar value 1 karega
                    let inputName = $(element.element).attr('name');
                    $('#remove_' + inputName).val(1); // Updates #remove_cover_image
                });
            }


            // GLOBAL MODAL RESET
            $(document).on('hidden.bs.modal', '.modal', function () {
                let form = $(this).find('form');
                if(form.length) { form[0].reset(); }
                $(this).find('button[type="submit"]').prop('disabled', false).each(function() {
                    let originalText = $(this).data('original-text') || 'Save';
                    $(this).text(originalText);
                });
            });

            // GLOBAL EYE ICON TOGGLE
            $(document).on('click', '.toggle-password', function() {
                let input = $(this).closest('.input-group').find('input');
                let icon = $(this).find('i');
                if (input.attr('type') === 'password') {
                    input.attr('type', 'text');
                    icon.removeClass('fa-eye').addClass('fa-eye-slash');
                } else {
                    input.attr('type', 'password');
                    icon.removeClass('fa-eye-slash').addClass('fa-eye');
                }
            });

            // GLOBAL IMAGE VIEWER
            $(document).on('click', '.view-image-btn', function(e) {
                e.preventDefault();
                let imageUrl = $(this).data('image'); 
                $('#globalViewerImage').attr('src', imageUrl); 
                var myModal = new bootstrap.Modal(document.getElementById('globalImageViewerModal'));
                myModal.show();
            });

            // GLOBAL SMART DATEPICKER
            $('.global-datepicker').each(function() {
                let element = $(this);
                let options = {
                    format: 'dd/mm/yyyy',
                    autoclose: true,
                    todayHighlight: true,
                    clearBtn: true
                };

                // Data attributes se exact start aur end date set karna
                if (element.attr('data-start-date')) { options.startDate = element.attr('data-start-date'); }
                if (element.attr('data-end-date')) { options.endDate = element.attr('data-end-date'); }

                element.datepicker(options);

                element.closest('.input-group').find('.calendar-icon').on('click', function() {
                    element.datepicker('show');
                });
            });

            // GLOBAL SMART DATEPICKER
            // Use class 'global-datepicker' on any input.
            // Add 'data-past-only="true"' for DOBs, or 'data-future-only="true"' for Events
            // $('.global-datepicker').each(function() {
            //     let element = $(this);
            //     let isPastOnly = element.data('past-only');
            //     let isFutureOnly = element.data('future-only');

            //     let options = {
            //         format: 'dd/mm/yyyy',
            //         autoclose: true,
            //         todayHighlight: true,
            //         clearBtn: true
            //     };

            //     if (isPastOnly) { options.endDate = '0d'; }
            //     if (isFutureOnly) { options.startDate = '0d'; }

            //     element.datepicker(options);

            //     // Connect calendar icon if it exists next to it
            //     element.closest('.input-group').find('.calendar-icon').on('click', function() {
            //         element.datepicker('show');
            //     });
            // });
        });

        $(document).ready(function() {
    
            // Global AJAX Pagination Logic
            // Ye document par delegated event hai, isliye naye load hue pagination buttons par bhi kaam karega
            $(document).on('click', '.ajax-pagination-container .pagination a', function(e) {
                e.preventDefault(); // Page reload hone se rokega
                
                let url = $(this).attr('href'); // Next page ka URL
                let container = $(this).closest('.ajax-pagination-container');
                let containerId = container.attr('id'); // e.g., 'login-history-table-container'

                // Optional: UI feedback (loading effect)
                container.css('opacity', '0.5');

                $.ajax({
                    url: url,
                    type: 'GET',
                    success: function(response) {
                        // Controller se poore page ka HTML aayega.
                        // Hum us HTML me se sirf us ID wala part nikalenge jo humein replace karna hai.
                        let newHtml = $(response).find('#' + containerId).html();
                        
                        // Content replace karein aur opacity wapas 1 kar dein
                        container.html(newHtml);
                        container.css('opacity', '1');
                    },
                    error: function() {
                        container.css('opacity', '1');
                        alert('Something went wrong while loading data.');
                    }
                });
            });

        });

        // GLOBAL DELETE CONFIRMATION FUNCTION
        // function confirmGlobalDelete(url, customText = "This action cannot be undone!") {
        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: customText,
        //         icon: 'warning',
        //         showCancelButton: true,
        //         confirmButtonColor: '#d33',
        //         cancelButtonColor: '#3085d6',
        //         confirmButtonText: 'Yes, delete it!'
        //     }).then((result) => {
        //         if (result.isConfirmed) {
        //             window.location.href = url;
        //         }
        //     });
        // }

        // GLOBAL SECURE DELETE CONFIRMATION FUNCTION
        // function confirmGlobalDelete(url, customText = "This action cannot be undone!") {
        //     Swal.fire({
        //         title: 'Are you sure?',
        //         text: customText,
        //         icon: 'warning',
        //         showCancelButton: true,
        //         confirmButtonColor: '#d33',
        //         cancelButtonColor: '#3085d6',
        //         confirmButtonText: 'Yes, delete it!'
        //     }).then((result) => {
        //         if (result.isConfirmed) {
        //             // Dynamically create a form for DELETE request
        //             let form = document.createElement('form');
        //             form.action = url;
        //             form.method = 'POST';

        //             // Add CSRF Token (Ensure aapke <head> me <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> ho)
        //             let csrfInput = document.createElement('input');
        //             csrfInput.type = 'hidden';
        //             csrfInput.name = '_token';
        //             csrfInput.value = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        //             form.appendChild(csrfInput);

        //             // Spoof DELETE Method
        //             let methodInput = document.createElement('input');
        //             methodInput.type = 'hidden';
        //             methodInput.name = '_method';
        //             methodInput.value = 'DELETE';
        //             form.appendChild(methodInput);

        //             document.body.appendChild(form);
        //             form.submit(); // Submit strictly as DELETE
        //         }
        //     });
        // }

        // GLOBAL SECURE DELETE CONFIRMATION FUNCTION
        function confirmGlobalDelete(url, customText = "This action cannot be undone!") {
            Swal.fire({
                title: 'Are you sure?',
                text: customText,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Dynamically create a form for DELETE request
                    let form = document.createElement('form');
                    form.action = url;
                    form.method = 'POST';

                    // Inject CSRF Token directly using Blade (No meta tag required)
                    let csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = '<?php echo e(csrf_token()); ?>';
                    form.appendChild(csrfInput);

                    // Spoof DELETE Method
                    let methodInput = document.createElement('input');
                    methodInput.type = 'hidden';
                    methodInput.name = '_method';
                    methodInput.value = 'DELETE';
                    form.appendChild(methodInput);

                    // Append and Submit
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        // AUTO LOGOUT DUE TO INACTIVITY (Admin Panel)
        let idleTime = 0;
        let idleInterval = setInterval(timerIncrement, 1000);

        $(document).on('mousemove keydown scroll click', function() {
            idleTime = 0;
        });

        function timerIncrement() {
            idleTime++;
            
            // 60 Seconds par page reload karenge (Future me 10 mins ke liye 600 kar dena)
            if (idleTime >= 600) {
                clearInterval(idleInterval);
                
                window.location.reload(); 
            }
        }
    </script>

    <!-- Dynamic Page Scripts -->
    <?php echo $__env->yieldPushContent('script'); ?>
  </body>
</html>
<?php /**PATH D:\Projects\teachyou\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>