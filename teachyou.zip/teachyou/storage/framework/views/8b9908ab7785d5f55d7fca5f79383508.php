

<?php $__env->startSection('title', 'Create Account'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-card">
    <div class="auth-header">
        <h3>Create an Account</h3>
        <p class="text-muted small mb-0">Join us and experience secure data handling.</p>
    </div>
    <div class="auth-body">
        <form id="frontendRegisterForm" action="<?php echo e(route('register.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
                <label for="name" class="form-label fw-bold small">Full Name <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-id-badge"></i></span>
                    <input type="text" class="form-control" id="name" name="name" placeholder="e.g. John Doe" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label for="username" class="form-label fw-bold small">Username <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" id="username" name="username" placeholder="e.g. johndoe123" required>
                </div>
            </div>

            <div class="form-group">
                <label for="email" class="form-label fw-bold small">Email Address <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    <input type="email" class="form-control" id="email" name="email" placeholder="e.g. john@example.com" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password" class="form-label fw-bold small">Password <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Min 8 characters" required>
                    <span class="input-group-text password-toggle"><i class="fas fa-eye"></i></span>
                </div>
                <div class="form-text text-muted" style="font-size: 11px;">
                    Must contain a capital letter, small letter, number, and special character.
                </div>
            </div>

            <div class="form-group">
                <label for="password_confirmation" class="form-label fw-bold small">Confirm Password <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm your password" required>
                    <span class="input-group-text password-toggle"><i class="fas fa-eye"></i></span>
                </div>
            </div>

            <!-- Message Container for AJAX Responses -->
            <div class="form-message mt-2" style="display: none;"></div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary w-100">Sign Up</button>
            </div>
            
            <div class="text-center mt-3 small">
                Already have an account? <a href="<?php echo e(route('login')); ?>" class="text-decoration-none fw-bold">Sign In</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\teachyou\resources\views/frontend/auth/register.blade.php ENDPATH**/ ?>