<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\EventController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\AuthController;
use \App\Http\Middleware\AdminAutoLogout;
use \App\Http\Middleware\CheckAdminStatus;

Route::get('/', function () {
    return redirect()->route('admin.dashboard');
});

// Laravel ke default auth middleware ke liye
Route::get('/login', function () {
    return redirect()->route('admin.login.index');
})->name('login');

Route::prefix('admin')->name('admin.')->group(function () {

    // 1. UNSECURED ROUTES (Guest Accessible)
    Route::middleware('guest')->group(function () {
        Route::get('/login', [AuthController::class, 'getLogin'])->name('login.index');
        Route::post('/login', [AuthController::class, 'postLogin'])->name('login');
        
        // Forgot password
        Route::get('/forgot/password', [AuthController::class, 'getForgotPassword'])->name('forgot.password.index');
        Route::post('/forgot/password', [AuthController::class, 'postForgotPassword'])->name('forgot.password');

        // Reset Password Page open karne ka route
        Route::get('/reset-password/{token}', [AuthController::class, 'getResetPassword'])->name('password.reset.index');

        //Naya password form submit karne ke liye
        Route::post('/reset-password', [AuthController::class, 'postResetPassword'])->name('password.reset');
    });

    // 2. SECURED ROUTES (Requires Login)
    Route::middleware(['auth', CheckAdminStatus::class, AdminAutoLogout::class ])->group(function () {
        
        // Logout Route
        Route::post('/logout', [AuthController::class, 'postLogout'])->name('logout');
        
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // User Management
        Route::prefix('users')
            ->name('users.')
            ->group(function () {
                Route::get('list', [UserController::class, 'getList'])->name('list');
                Route::get('create', [UserController::class, 'getCreate'])->name('create.index');
                Route::post('create', [UserController::class, 'postCreate'])->name('create');
                Route::get('update/{id?}', [UserController::class, 'getUpdate'])->name('update.index');
                Route::post('update/{id?}', [UserController::class, 'postUpdate'])->name('update');
                Route::get('delete/{id?}', [UserController::class, 'getDelete'])->name('delete');
                Route::get('change/status/{id?}', [UserController::class, 'getChangeStatus'])->name('change.status');
        });

        Route::prefix('events')
            ->name('events.')
            ->group(function () {
                Route::get('list', [EventController::class, 'getList'])->name('list');
                Route::get('update/{id}', [EventController::class, 'getUpdate'])->name('update.index');
                Route::post('update/{id}', [EventController::class, 'postUpdate'])->name('update');
                Route::get('delete/{id}', [EventController::class, 'getDelete'])->name('delete');

                // Event Attendees
                // Route::get('attendees', [EventController::class, 'getAttendeesList'])->name('attendees.list');
                
        });

        Route::prefix('categories')
            ->name('categories.')
            ->group(function () {

                Route::get('list', [CategoryController::class, 'getList'])->name('list');
                Route::post('create', [CategoryController::class, 'postCreate'])->name('create');
                Route::post('update/{id}', [CategoryController::class, 'postUpdate'])->name('update');
                Route::get('delete/{id}', [CategoryController::class, 'getDelete'])->name('delete');
                
        });
        
        // Future Modules
    });
});