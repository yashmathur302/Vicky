<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Frontend\AuthController as FrontendAuthController;
use App\Http\Controllers\Frontend\HomeController;

// Frontend Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [FrontendAuthController::class, 'getLogin'])->name('login');
    Route::post('/login-submit', [FrontendAuthController::class, 'postLogin'])->name('login.submit');
    
    Route::get('/register', [FrontendAuthController::class, 'getRegister'])->name('register');
    Route::post('/register-submit', [FrontendAuthController::class, 'postRegister'])->name('register.submit');
});

Route::post('/logout', [FrontendAuthController::class, 'postLogout'])->name('logout')->middleware('auth');

// Dummy Dashboard for testing
// Route::get('/home', function () {
//     return '<div style="text-align:center; margin-top:50px; font-family:sans-serif;">
//                 <h2>Welcome to Frontend Home!</h2>
//                 <form action="'.route('logout').'" method="POST">
//                     '.csrf_field().'
//                     <button type="submit" style="padding:10px 20px; background:red; color:white; border:none; border-radius:5px; cursor:pointer;">Logout</button>
//                 </form>
//             </div>';
// })->name('home')->middleware('auth');

Route::get('/home', [HomeController::class, 'index'])->name('home')->middleware('auth');